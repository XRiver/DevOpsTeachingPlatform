var showDeployInfo = function() {
    setTimeout(function(){
        info = "任务上次成功部署于：2018-5-22 19:07:22\n当前正在运行... ...";
        $('#deployInfoArea').text(info);
    },1500);
}

var showPanes = function() {
    $('#taskPane').show();
    $('#imagePane').show();
}