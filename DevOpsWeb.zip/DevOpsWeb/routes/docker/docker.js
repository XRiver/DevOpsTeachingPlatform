var express = require('express');

var router = express.Router();

router.get('/', function(req, res, next) {
    res.render('docker',{
        realName:"徐江河",
        sess:req.session
    })
})


module.exports = router;
