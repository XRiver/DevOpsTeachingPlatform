var out = {
    frontIp:'localhost:3000',
    teamIp:'139.219.66.203:8089',
    gitIp:'139.219.66.203:8762'
}

module.exports = out;